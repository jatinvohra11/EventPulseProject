package com.eventpulse.app.ui.screens.login

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay

// ---------------------------------------------------------
// EVENTPULSE COLORS
// ---------------------------------------------------------

private val OffWhite = Color(0xFFF8FAFC)
private val SkyBlue = Color(0xFF0797D1)
private val SkyBlueDark = Color(0xFF087EAE)
private val DarkText = Color(0xFF172033)
private val SoftText = Color(0xFF64748B)
private val BorderGrey = Color(0xFFD8E1EA)
private val ErrorRed = Color(0xFFD32F2F)

// ---------------------------------------------------------
// STUDENT LOGIN SCREEN
// ---------------------------------------------------------

@Composable
fun StudentLoginScreen(
    onLogin: () -> Unit = {},
    onGoogleLogin: () -> Unit = {},
    onCreateAccount: () -> Unit = {},
    onOrganizerLogin: () -> Unit = {}
) {

    // -----------------------------------------------------
    // FORM STATES
    // -----------------------------------------------------

    var email by remember {
        mutableStateOf("")
    }

    var password by remember {
        mutableStateOf("")
    }

    var passwordVisible by remember {
        mutableStateOf(false)
    }

    var showContent by remember {
        mutableStateOf(false)
    }

    var isLoading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    var forgotPasswordMessage by remember {
        mutableStateOf("")
    }

    val auth = remember {
        FirebaseAuth.getInstance()
    }

    // -----------------------------------------------------
// TYPING ANIMATION
// -----------------------------------------------------

    var typedText by remember {
        mutableStateOf("")
    }

    val appName = "EventPulse"

// -----------------------------------------------------
// SCREEN ENTRY ANIMATION
// -----------------------------------------------------

    LaunchedEffect(Unit) {

        showContent = true

        while (true) {

            // TYPE
            for (i in 1..appName.length) {
                typedText = appName.substring(0, i)
                delay(110)
            }

            // HOLD
            delay(1800)

            // DELETE
            for (i in appName.length downTo 0) {
                typedText = appName.substring(0, i)
                delay(70)
            }

            // SMALL GAP
            delay(500)
        }
    }

    // -----------------------------------------------------
    // BLINKING CURSOR
    // -----------------------------------------------------

    val infiniteTransition = rememberInfiniteTransition(
        label = "cursorTransition"
    )

    val cursorAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(550),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursorAlpha"
    )

    // -----------------------------------------------------
    // TOP LOGO SCALE
    // -----------------------------------------------------

    val logoScale by animateFloatAsState(
        targetValue = if (showContent) 1f else 0.85f,
        animationSpec = tween(
            durationMillis = 700,
            easing = FastOutSlowInEasing
        ),
        label = "logoScale"
    )

    // -----------------------------------------------------
    // SCREEN
    // -----------------------------------------------------

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 28.dp,
                    vertical = 32.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // -------------------------------------------------
            // EVENTPULSE APP NAME
            // -------------------------------------------------

            Spacer(
                modifier = Modifier.height(24.dp)
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.scale(logoScale)
            ) {

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Text(
                        text = typedText,
                        color = SkyBlue,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = (-0.8).sp
                    )

                    // Typing cursor
                    Text(
                        text = "|",
                        color = SkyBlue,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.alpha(cursorAlpha)
                    )
                }

                Spacer(
                    modifier = Modifier.height(5.dp)
                )

                Text(
                    text = "DISCOVER  •  PLAN  •  BELONG",
                    color = SoftText,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 2.2.sp
                )
            }

            Spacer(
                modifier = Modifier.height(58.dp)
            )

            // -------------------------------------------------
            // LOGIN CONTENT
            // -------------------------------------------------

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(
                    animationSpec = tween(800)
                ) + slideInVertically(
                    initialOffsetY = { 40 },
                    animationSpec = tween(
                        800,
                        easing = FastOutSlowInEasing
                    )
                )
            ) {

                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {

                    // -------------------------------------------------
                    // EMAIL
                    // -------------------------------------------------

                    Text(
                        text = "Student Email",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            errorMessage = ""
                            forgotPasswordMessage = ""
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your university email",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 14.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText,
                            cursorColor = SkyBlue
                        )
                    )

                    Spacer(
                        modifier = Modifier.height(20.dp)
                    )

                    // -------------------------------------------------
                    // PASSWORD
                    // -------------------------------------------------

                    Text(
                        text = "Password",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = ""
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your password",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 14.sp
                            )
                        },
                        visualTransformation = if (passwordVisible) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password
                        ),
                        trailingIcon = {

                            Text(
                                text = if (passwordVisible) {
                                    "HIDE"
                                } else {
                                    "SHOW"
                                },
                                color = SkyBlue,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .padding(end = 14.dp)
                                    .clickable {
                                        passwordVisible = !passwordVisible
                                    }
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText,
                            cursorColor = SkyBlue
                        )
                    )

                    // -------------------------------------------------
                    // FORGOT PASSWORD
                    // -------------------------------------------------

                    Box(
                        modifier = Modifier.fillMaxWidth()
                    ) {

                        Text(
                            text = "Forgot password?",
                            color = SkyBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(
                                    top = 8.dp
                                )
                                .clickable {

                                    errorMessage = ""
                                    forgotPasswordMessage = ""

                                    if (email.trim().isEmpty()) {

                                        errorMessage =
                                            "Enter your email first"

                                    } else {

                                        auth.sendPasswordResetEmail(
                                            email.trim()
                                        ).addOnCompleteListener { task ->

                                            if (task.isSuccessful) {

                                                forgotPasswordMessage =
                                                    "Password reset email sent."

                                            } else {

                                                errorMessage =
                                                    task.exception?.message
                                                        ?: "Unable to send reset email."
                                            }
                                        }
                                    }
                                }
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(22.dp)
                    )

                    // -------------------------------------------------
                    // ERROR MESSAGE
                    // -------------------------------------------------

                    if (errorMessage.isNotEmpty()) {

                        Text(
                            text = errorMessage,
                            color = ErrorRed,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    bottom = 10.dp
                                )
                        )
                    }

                    // -------------------------------------------------
                    // FORGOT PASSWORD SUCCESS MESSAGE
                    // -------------------------------------------------

                    if (forgotPasswordMessage.isNotEmpty()) {

                        Text(
                            text = forgotPasswordMessage,
                            color = SkyBlueDark,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    bottom = 10.dp
                                )
                        )
                    }

                    // -------------------------------------------------
                    // LOGIN BUTTON
                    // -------------------------------------------------

                    Button(
                        onClick = {
                            errorMessage = ""
                            forgotPasswordMessage = ""

                            val cleanEmail = email.trim()

                            when {
                                cleanEmail.isEmpty() -> {
                                    errorMessage = "Please enter your student email"
                                }

                                password.isEmpty() -> {
                                    errorMessage = "Please enter your password"
                                }

                                else -> {
                                    isLoading = true

                                    auth.signInWithEmailAndPassword(
                                        cleanEmail,
                                        password
                                    ).addOnCompleteListener { task ->

                                        isLoading = false

                                        if (task.isSuccessful) {
                                            onLogin()
                                        } else {
                                            errorMessage =
                                                task.exception?.message
                                                    ?: "Login failed. Please check your email and password."
                                        }
                                    }
                                }
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SkyBlue,
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(
                            defaultElevation = 5.dp,
                            pressedElevation = 1.dp
                        )
                    ) {

                        Text(
                            text = if (isLoading) {
                                "Logging in..."
                            } else {
                                "Login"
                            },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(26.dp)
                    )

                    // -------------------------------------------------
                    // OR
                    // -------------------------------------------------

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = BorderGrey
                        )

                        Text(
                            text = "  OR  ",
                            color = SoftText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )

                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = BorderGrey
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(24.dp)
                    )

                    // -------------------------------------------------
                    // GOOGLE LOGIN
                    // -------------------------------------------------

                    Button(
                        onClick = onGoogleLogin,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(55.dp)
                            .border(
                                width = 1.dp,
                                color = BorderGrey,
                                shape = RoundedCornerShape(14.dp)
                            ),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = DarkText
                        ),
                        elevation = ButtonDefaults.buttonElevation(
                            defaultElevation = 2.dp
                        )
                    ) {

                        Text(
                            text = "G",
                            color = SkyBlueDark,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(
                            modifier = Modifier.size(10.dp)
                        )

                        Text(
                            text = "Continue with Google",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(20.dp)
                    )

                    // -------------------------------------------------
                    // CREATE STUDENT ACCOUNT
                    // -------------------------------------------------

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clickable {
                                onCreateAccount()
                            },
                        contentAlignment = Alignment.Center
                    ) {

                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Text(
                                text = "New to EventPulse?",
                                color = SoftText,
                                fontSize = 11.sp
                            )

                            Spacer(
                                modifier = Modifier.width(5.dp)
                            )

                            Text(
                                text = "Create Student Account",
                                color = SkyBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // -------------------------------------------------
                    // ORGANIZER LOGIN
                    // -------------------------------------------------

                    Spacer(
                        modifier = Modifier.height(4.dp)
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clickable {
                                onOrganizerLogin()
                            },
                        contentAlignment = Alignment.Center
                    ) {

                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Text(
                                text = "Are you an organizer?",
                                color = SoftText,
                                fontSize = 11.sp
                            )

                            Spacer(
                                modifier = Modifier.width(5.dp)
                            )

                            Text(
                                text = "Organizer Login",
                                color = SkyBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}