package com.eventpulse.app.ui.screens.home
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import androidx.compose.foundation.rememberScrollState
import kotlinx.coroutines.delay

// -------------------------------------------------
// EVENTPULSE COLORS
// -------------------------------------------------

private val OffWhite = Color(0xFFF8FAFC)
private val SkyBlue = Color(0xFF0797D1)
private val SkyBlueDark = Color(0xFF087EAE)
private val DarkText = Color(0xFF172033)
private val SoftText = Color(0xFF64748B)
private val BorderGrey = Color(0xFFDCE4EC)
private val LightBlue = Color(0xFFE4F5FB)
private val White = Color.White

// -------------------------------------------------
// DATA
// -------------------------------------------------

private data class EventItem(
    val title: String,
    val category: String,
    val date: String,
    val venue: String,
    val interested: String,
    val gradient: List<Color>
)

private data class CategoryItem(
    val name: String,
    val icon: ImageVector
)

private data class ClubItem(
    val name: String,
    val description: String,
    val members: String,
    val gradient: List<Color>
)

// -------------------------------------------------
// MAIN STUDENT HOME
// -------------------------------------------------

@Composable
fun StudentHomeScreen(
    onLogout: () -> Unit = {}
) {

    val auth = remember {
        FirebaseAuth.getInstance()
    }

    var selectedTab by remember {
        mutableIntStateOf(0)
    }

    var showChatbot by remember {
        mutableStateOf(false)
    }

    var showSettings by remember {
        mutableStateOf(false)
    }
    val user = auth.currentUser

    val studentName = remember(user) {
        val displayName = user?.displayName

        if (!displayName.isNullOrBlank()) {
            displayName
        } else {
            user?.email
                ?.substringBefore("@")
                ?.replaceFirstChar {
                    it.uppercase()
                }
                ?: "Student"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        Column(
            modifier = Modifier.fillMaxSize()
        ) {

            Box(
                modifier = Modifier.weight(1f)
            ) {

                when (selectedTab) {

                    0 -> HomeContent(
                        studentName = studentName
                    )

                    1 -> ExploreContent()

                    2 -> MyEventsContent()

                    3 -> ClubsContent()

                    4 -> ProfileContent(
                        studentName = studentName,
                        email = user?.email ?: "",
                        onSettings = {
                            showSettings = true
                        },
                        onLogout = {
                            auth.signOut()
                            onLogout()
                        }
                    )
                }
            }

            BottomNavigationBar(
                selectedTab = selectedTab,
                onTabSelected = {
                    selectedTab = it
                }
            )
        }

        // -------------------------------------------------
        // FLOATING AI CHATBOT
        // -------------------------------------------------

        ChatbotFloatingButton(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(
                    end = 18.dp,
                    bottom = 76.dp
                ),
            onClick = {
                showChatbot = true
            }
        )
    }

    // -------------------------------------------------
    // CHATBOT DIALOG
    // -------------------------------------------------

    if (showChatbot) {

        AlertDialog(
            onDismissRequest = {
                showChatbot = false
            },

            icon = {
                Icon(
                    imageVector = Icons.Default.Chat,
                    contentDescription = null,
                    tint = SkyBlue
                )
            },

            title = {
                Text(
                    text = "EventPulse AI",
                    fontWeight = FontWeight.Bold
                )
            },

            text = {
                Text(
                    text = "Hi $studentName 👋\n\n" +
                            "I'm your campus assistant. Soon I will help you discover events, clubs, workshops and activities based on your interests.",
                    color = SoftText
                )
            },

            confirmButton = {
                TextButton(
                    onClick = {
                        showChatbot = false
                    }
                ) {
                    Text(
                        text = "Got it",
                        color = SkyBlue,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }

    // -------------------------------------------------
    // SETTINGS
    // -------------------------------------------------

    if (showSettings) {

        SettingsDialog(
            onDismiss = {
                showSettings = false
            }
        )
    }
}

// =====================================================
// HOME CONTENT
// =====================================================

@Composable
private fun HomeContent(
    studentName: String
) {

    val events = remember {
        listOf(
            EventItem(
                "Cultural Fest 2K26",
                "Cultural",
                "15 Oct 2026",
                "University Ground",
                "500+ interested",
                listOf(
                    Color(0xFF26123D),
                    Color(0xFFE93672)
                )
            ),

            EventItem(
                "AI & Future Tech Workshop",
                "Tech",
                "12 Sep 2026",
                "Block 25",
                "120+ interested",
                listOf(
                    Color(0xFF063B55),
                    Color(0xFF20B7E8)
                )
            ),

            EventItem(
                "Inter Block Football",
                "Sports",
                "25 Sep 2026",
                "Sports Complex",
                "200+ interested",
                listOf(
                    Color(0xFF06482D),
                    Color(0xFF4CAF50)
                )
            )
        )
    }

    var isSearchOpen by remember {
        mutableStateOf(false)
    }

    var searchQuery by remember {
        mutableStateOf("")
    }

    val filteredEvents = if (searchQuery.isBlank()) {
        events
    } else {
        events.filter { event ->
            event.title.contains(searchQuery, ignoreCase = true) ||
                    event.category.contains(searchQuery, ignoreCase = true) ||
                    event.venue.contains(searchQuery, ignoreCase = true)
        }
    }

    val categories = remember {
        listOf(
            CategoryItem("Tech", Icons.Default.Work),
            CategoryItem("Cultural", Icons.Default.Campaign),
            CategoryItem("Sports", Icons.Default.SportsSoccer),
            CategoryItem("Workshops", Icons.Default.CalendarMonth),
            CategoryItem("Clubs", Icons.Default.Group)
        )
    }

    val clubs = remember {
        listOf(
            ClubItem(
                "Coding Club",
                "We love to code the future!",
                "487 members",
                listOf(
                    Color(0xFF073B4C),
                    Color(0xFF20A4E0)
                )
            ),

            ClubItem(
                "Photography Club",
                "Capture moments. Tell stories.",
                "225 members",
                listOf(
                    Color(0xFF24445A),
                    Color(0xFF82C4D8)
                )
            ),

            ClubItem(
                "Music Society",
                "Feel the rhythm of campus.",
                "310 members",
                listOf(
                    Color(0xFF402060),
                    Color(0xFFCE5A8B)
                )
            )
        )
    }

    val infiniteTransition = rememberInfiniteTransition(
        label = "background"
    )

    val floatingOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 14f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 2800,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "floating"
    )

    var bannerIndex by remember {
        mutableIntStateOf(0)
    }

    LaunchedEffect(Unit) {

        while (true) {

            delay(3500)

            bannerIndex =
                (bannerIndex + 1) % events.size
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            top = 18.dp,
            bottom = 28.dp
        )
    ) {

        // -------------------------------------------------
        // HEADER
        // -------------------------------------------------

        item {

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isSearchOpen) 185.dp else 165.dp)
            ) {

                // Floating decorative circles
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .offset(
                            x = 280.dp,
                            y = (-45).dp + floatingOffset.dp
                        )
                        .alpha(0.15f)
                        .clip(CircleShape)
                        .background(SkyBlue)
                )

                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .offset(
                            x = (-25).dp,
                            y = 35.dp - floatingOffset.dp
                        )
                        .alpha(0.10f)
                        .clip(CircleShape)
                        .background(SkyBlue)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                ) {

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        AnimatedVisibility(
                            visible = isSearchOpen,
                            enter = fadeIn() + expandHorizontally(),
                            exit = fadeOut() + shrinkHorizontally(),
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp),
                                placeholder = {
                                    Text(
                                        text = "Search events, clubs...",
                                        color = SoftText,
                                        fontSize = 13.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search",
                                        tint = SkyBlue
                                    )
                                },
                                trailingIcon = {
                                    IconButton(
                                        onClick = {
                                            searchQuery = ""
                                            isSearchOpen = false
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Close search",
                                            tint = SoftText
                                        )
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(17.dp)
                            )
                        }

                        if (!isSearchOpen) {
                            IconButton(
                                onClick = { isSearchOpen = true },
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(White, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search events",
                                    tint = SkyBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        IconButton(
                            onClick = {},
                            modifier = Modifier
                                .size(46.dp)
                                .background(White, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications",
                                tint = SkyBlue,
                                modifier = Modifier.size(23.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(LightBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Profile",
                                tint = SkyBlue,
                                modifier = Modifier.size(25.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "HELLO",
                        fontSize = 13.sp,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold,
                        color = SoftText
                    )

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = "$studentName 👋",
                        fontSize = 27.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(5.dp))

                    Text(
                        text = "Discover what's happening on your campus",
                        fontSize = 13.sp,
                        color = SoftText
                    )
                }
            }
        }

        // -------------------------------------------------
        // HERO BANNER
        // -------------------------------------------------

        item {

            HeroBanner(
                event = events[bannerIndex]
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {

                repeat(events.size) { index ->

                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .size(
                                width = if (index == bannerIndex) 28.dp else 8.dp,
                                height = 8.dp
                            )
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (index == bannerIndex)
                                    SkyBlue
                                else
                                    BorderGrey
                            )
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(26.dp)
            )
        }

        // -------------------------------------------------
        // LIVE EVENTS
        // -------------------------------------------------

        item {

            SectionTitle(
                title = "LIVE EVENTS",
                onViewAll = {}
            )

            Spacer(
                modifier = Modifier.height(10.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(
                    horizontal = 20.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {

                items(events) { event ->

                    LiveEventCard(
                        event = event
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(28.dp)
            )
        }

        // -------------------------------------------------
        // CATEGORIES
        // -------------------------------------------------

        item {

            SectionTitle(
                title = "EXPLORE CATEGORIES",
                onViewAll = {}
            )

            Spacer(
                modifier = Modifier.height(10.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(
                    horizontal = 20.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {

                items(categories) { category ->

                    CategoryChip(
                        category = category
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(30.dp)
            )
        }

        // -------------------------------------------------
        // RECOMMENDED
        // -------------------------------------------------

        item {

            SectionTitle(
                title = "EVENTS FOR YOU",
                onViewAll = {}
            )

            Spacer(
                modifier = Modifier.height(10.dp)
            )
        }

        if (searchQuery.isNotBlank()) {
            item {
                Text(
                    text = if (filteredEvents.isEmpty()) {
                        "No events found"
                    } else {
                        "${filteredEvents.size} result(s) found"
                    },
                    modifier = Modifier.padding(horizontal = 20.dp),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SoftText
                )

                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        items(filteredEvents) { event ->

            EventCard(
                event = event
            )

            Spacer(
                modifier = Modifier.height(14.dp)
            )
        }

        // -------------------------------------------------
        // CLUBS
        // -------------------------------------------------

        item {

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            SectionTitle(
                title = "CLUBS FOR YOU",
                onViewAll = {}
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(
                    horizontal = 20.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {

                items(clubs) { club ->

                    ClubCard(
                        club = club
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(30.dp)
            )
        }

        // -------------------------------------------------
        // COMMUNITIES
        // -------------------------------------------------

        item {

            SectionTitle(
                title = "COMMUNITIES FOR YOU",
                onViewAll = {}
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(
                    horizontal = 20.dp
                ),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {

                items(
                    listOf(
                        "Photography",
                        "Music",
                        "Hackathons",
                        "Entrepreneurs"
                    )
                ) { community ->

                    CommunityCard(
                        name = community
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(30.dp)
            )
        }

        // -------------------------------------------------
        // HOBBIES
        // -------------------------------------------------

        item {

            SectionTitle(
                title = "BROWSE BY HOBBIES",
                onViewAll = {}
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(
                        rememberScrollState()
                    )
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                HobbyCard(
                    name = "Music",
                    gradient = listOf(
                        Color(0xFF172B4D),
                        Color(0xFF587B9A)
                    )
                )

                HobbyCard(
                    name = "Hackathons",
                    gradient = listOf(
                        Color(0xFF173B43),
                        Color(0xFF4C8B96)
                    )
                )

                HobbyCard(
                    name = "Sports",
                    gradient = listOf(
                        Color(0xFF14532D),
                        Color(0xFF65A30D)
                    )
                )
            }

            Spacer(
                modifier = Modifier.height(30.dp)
            )
        }

        // -------------------------------------------------
        // EVENT MEMORIES
        // -------------------------------------------------

        item {

            SectionTitle(
                title = "EVENT MEMORIES",
                onViewAll = {}
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            MemoryCard(
                title = "Rahagir at Freshman Induction",
                date = "10 Aug 2026"
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            MemoryCard(
                title = "Comic Verse",
                date = "3 Sep 2026"
            )

            Spacer(
                modifier = Modifier.height(28.dp)
            )
        }

        // -------------------------------------------------
        // GALLERY
        // -------------------------------------------------

        item {

            SectionTitle(
                title = "EVENT GALLERY",
                onViewAll = {}
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            GalleryCard()

            Spacer(
                modifier = Modifier.height(24.dp)
            )
        }
    }
}

// =====================================================
// SEARCH BAR
// =====================================================

@Composable
private fun SearchBar(
    onClick: () -> Unit
) {

    OutlinedTextField(
        value = "",
        onValueChange = {},
        enabled = false,
        placeholder = {
            Text(
                text = "Search events, clubs, communities...",
                color = SoftText
            )
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = SkyBlue
            )
        },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .clickable {
                onClick()
            },
        shape = RoundedCornerShape(20.dp)
    )
}

// =====================================================
// HERO
// =====================================================

@Composable
private fun HeroBanner(
    event: EventItem
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 6.dp
        )
    ) {

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(205.dp)
                .background(
                    Brush.linearGradient(
                        colors = event.gradient
                    )
                )
                .padding(20.dp)
        ) {

            Column(
                modifier = Modifier.fillMaxSize()
            ) {

                Text(
                    text = event.category.uppercase(),
                    fontSize = 11.sp,
                    letterSpacing = 2.sp,
                    color = White,
                    fontWeight = FontWeight.Bold
                )

                Spacer(
                    modifier = Modifier.height(22.dp)
                )

                Text(
                    text = event.title,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = White,
                    maxLines = 2
                )

                Spacer(
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = "${event.date}  •  ${event.venue}",
                    fontSize = 11.sp,
                    color = White
                )
            }
        }
    }
}

// =====================================================
// SECTION TITLE
// =====================================================

@Composable
private fun SectionTitle(
    title: String,
    onViewAll: () -> Unit
) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        Box(
            modifier = Modifier
                .width(42.dp)
                .height(1.dp)
                .background(BorderGrey)
        )

        Text(
            text = title,
            modifier = Modifier.padding(
                horizontal = 10.dp
            ),
            fontSize = 17.sp,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold,
            color = DarkText
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(BorderGrey)
        )

        Text(
            text = "See All",
            modifier = Modifier
                .padding(start = 10.dp)
                .clickable {
                    onViewAll()
                },
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = SkyBlue
        )
    }
}

// =====================================================
// LIVE EVENT CARD
// =====================================================

@Composable
private fun LiveEventCard(
    event: EventItem
) {

    Card(
        modifier = Modifier.width(310.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {

        Column {

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(
                        Brush.linearGradient(
                            event.gradient
                        )
                    )
            ) {

                Text(
                    text = event.category.uppercase(),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(18.dp),
                    color = White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "LIVE",
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(14.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFFE53935))
                        .padding(
                            horizontal = 10.dp,
                            vertical = 5.dp
                        ),
                    color = White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(
                modifier = Modifier.padding(16.dp)
            ) {

                Text(
                    text = event.title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = DarkText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(
                    modifier = Modifier.height(6.dp)
                )

                Text(
                    text = event.date,
                    fontSize = 12.sp,
                    color = SoftText
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                OutlinedButton(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {

                    Text(
                        text = "View Event",
                        color = SkyBlue,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// =====================================================
// CATEGORY
// =====================================================

@Composable
private fun CategoryChip(
    category: CategoryItem
) {

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = White,
        shadowElevation = 2.dp
    ) {

        Row(
            modifier = Modifier.padding(
                horizontal = 15.dp,
                vertical = 11.dp
            ),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Icon(
                imageVector = category.icon,
                contentDescription = null,
                tint = SkyBlue,
                modifier = Modifier.size(18.dp)
            )

            Spacer(
                modifier = Modifier.width(7.dp)
            )

            Text(
                text = category.name,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = DarkText
            )
        }
    }
}

// =====================================================
// EVENT CARD
// =====================================================

@Composable
private fun EventCard(
    event: EventItem
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier
                    .size(105.dp)
                    .clip(RoundedCornerShape(17.dp))
                    .background(
                        Brush.linearGradient(
                            event.gradient
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {

                Text(
                    text = event.category.uppercase(),
                    color = White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(
                modifier = Modifier.width(14.dp)
            )

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Surface(
                    shape = RoundedCornerShape(30.dp),
                    color = LightBlue
                ) {

                    Text(
                        text = event.category,
                        modifier = Modifier.padding(
                            horizontal = 10.dp,
                            vertical = 5.dp
                        ),
                        color = SkyBlueDark,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(
                    modifier = Modifier.height(7.dp)
                )

                Text(
                    text = event.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = DarkText,
                    maxLines = 2
                )

                Spacer(
                    modifier = Modifier.height(5.dp)
                )

                Text(
                    text = event.date,
                    fontSize = 11.sp,
                    color = SoftText
                )

                Text(
                    text = event.venue,
                    fontSize = 11.sp,
                    color = SoftText
                )

                Text(
                    text = event.interested,
                    fontSize = 10.sp,
                    color = SoftText
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = SkyBlue
            )
        }
    }
}

// =====================================================
// CLUB CARD
// =====================================================

@Composable
private fun ClubCard(
    club: ClubItem
) {

    Card(
        modifier = Modifier.width(290.dp),
        shape = RoundedCornerShape(22.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {

        Column {

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(135.dp)
                    .background(
                        Brush.linearGradient(
                            club.gradient
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {

                Icon(
                    imageVector = Icons.Default.Group,
                    contentDescription = null,
                    tint = White,
                    modifier = Modifier.size(55.dp)
                )
            }

            Column(
                modifier = Modifier.padding(16.dp)
            ) {

                Text(
                    text = club.name,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = DarkText
                )

                Text(
                    text = club.description,
                    fontSize = 12.sp,
                    color = SoftText
                )

                Spacer(
                    modifier = Modifier.height(8.dp)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = null,
                        tint = SkyBlue,
                        modifier = Modifier.size(16.dp)
                    )

                    Spacer(
                        modifier = Modifier.width(5.dp)
                    )

                    Text(
                        text = club.members,
                        fontSize = 11.sp,
                        color = SoftText
                    )
                }

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Button(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SkyBlue
                    )
                ) {

                    Text(
                        text = "Join Club",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// =====================================================
// COMMUNITY CARD
// =====================================================

@Composable
private fun CommunityCard(
    name: String
) {

    Box(
        modifier = Modifier
            .width(190.dp)
            .height(115.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF183B4D),
                        SkyBlue
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {

        Text(
            text = name,
            color = White,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

// =====================================================
// HOBBY CARD
// =====================================================

@Composable
private fun HobbyCard(
    name: String,
    gradient: List<Color>
) {

    Box(
        modifier = Modifier
            .width(180.dp)
            .height(120.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    gradient
                )
            ),
        contentAlignment = Alignment.Center
    ) {

        Text(
            text = name,
            color = White,
            fontSize = 20.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

// =====================================================
// MEMORY CARD
// =====================================================

@Composable
private fun MemoryCard(
    title: String,
    date: String
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 3.dp
        )
    ) {

        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier
                    .size(105.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                SkyBlueDark,
                                SkyBlue
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {

                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = null,
                    tint = White,
                    modifier = Modifier.size(35.dp)
                )
            }

            Spacer(
                modifier = Modifier.width(14.dp)
            )

            Column {

                Text(
                    text = "EventPulse Memories",
                    fontSize = 10.sp,
                    color = SkyBlue
                )

                Spacer(
                    modifier = Modifier.height(5.dp)
                )

                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = DarkText
                )

                Spacer(
                    modifier = Modifier.height(5.dp)
                )

                Text(
                    text = date,
                    fontSize = 11.sp,
                    color = SoftText
                )
            }
        }
    }
}

// =====================================================
// GALLERY
// =====================================================

@Composable
private fun GalleryCard() {

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .height(230.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF203B55),
                        Color(0xFF2FA7CF)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Icon(
                imageVector = Icons.Default.CalendarMonth,
                contentDescription = null,
                tint = White,
                modifier = Modifier.size(55.dp)
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            Text(
                text = "Campus Event Gallery",
                color = White,
                fontSize = 21.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Text(
                text = "Memories • Moments • Community",
                color = White.copy(alpha = 0.8f),
                fontSize = 11.sp
            )
        }
    }
}

// =====================================================
// EXPLORE
// =====================================================

@Composable
private fun ExploreContent() {

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = 20.dp,
            vertical = 24.dp
        )
    ) {

        item {

            Text(
                text = "Explore",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = DarkText
            )

            Text(
                text = "Find something interesting on campus.",
                color = SoftText
            )

            Spacer(
                modifier = Modifier.height(24.dp)
            )
        }

        item {

            SearchBar(
                onClick = {}
            )

            Spacer(
                modifier = Modifier.height(24.dp)
            )
        }

        items(
            listOf(
                "Hackathons",
                "Workshops",
                "Cultural Events",
                "Sports",
                "Technical Events",
                "Clubs",
                "Communities"
            )
        ) { name ->

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .clickable {},
                shape = RoundedCornerShape(18.dp)
            ) {

                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Box(
                        modifier = Modifier
                            .size(45.dp)
                            .clip(CircleShape)
                            .background(LightBlue),
                        contentAlignment = Alignment.Center
                    ) {

                        Icon(
                            imageVector = Icons.Default.Explore,
                            contentDescription = null,
                            tint = SkyBlue
                        )
                    }

                    Spacer(
                        modifier = Modifier.width(14.dp)
                    )

                    Text(
                        text = name,
                        modifier = Modifier.weight(1f),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        tint = SkyBlue
                    )
                }
            }
        }
    }
}

// =====================================================
// MY EVENTS
// =====================================================

@Composable
private fun MyEventsContent() {

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = 20.dp,
            vertical = 24.dp
        )
    ) {

        item {

            Text(
                text = "My Events",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = DarkText
            )

            Text(
                text = "Your registrations and saved events.",
                color = SoftText
            )

            Spacer(
                modifier = Modifier.height(25.dp)
            )
        }

        item {

            MyEventStatus(
                icon = Icons.Default.CheckCircle,
                title = "Registered Events",
                subtitle = "Events you have joined"
            )

            MyEventStatus(
                icon = Icons.Default.Favorite,
                title = "Saved Events",
                subtitle = "Events you want to attend"
            )

            MyEventStatus(
                icon = Icons.Default.CalendarMonth,
                title = "Upcoming Events",
                subtitle = "Your next campus activities"
            )
        }
    }
}

// =====================================================
// MY EVENT STATUS
// =====================================================

@Composable
private fun MyEventStatus(
    icon: ImageVector,
    title: String,
    subtitle: String
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(18.dp)
    ) {

        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = SkyBlue,
                modifier = Modifier.size(28.dp)
            )

            Spacer(
                modifier = Modifier.width(15.dp)
            )

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    color = DarkText
                )

                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = SoftText
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = SoftText
            )
        }
    }
}

// =====================================================
// CLUBS
// =====================================================

@Composable
private fun ClubsContent() {

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            vertical = 24.dp
        )
    ) {

        item {

            Text(
                text = "Campus Clubs",
                modifier = Modifier.padding(
                    horizontal = 20.dp
                ),
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = DarkText
            )

            Text(
                text = "Connect with people who share your interests.",
                modifier = Modifier.padding(
                    horizontal = 20.dp
                ),
                color = SoftText
            )

            Spacer(
                modifier = Modifier.height(22.dp)
            )
        }

        items(
            listOf(
                ClubItem(
                    "Coding Club",
                    "We love to code the future!",
                    "487 members",
                    listOf(
                        Color(0xFF073B4C),
                        Color(0xFF20A4E0)
                    )
                ),
                ClubItem(
                    "Photography Club",
                    "Capture moments. Tell stories.",
                    "225 members",
                    listOf(
                        Color(0xFF24445A),
                        Color(0xFF82C4D8)
                    )
                ),
                ClubItem(
                    "Music Society",
                    "Feel the rhythm of campus.",
                    "310 members",
                    listOf(
                        Color(0xFF402060),
                        Color(0xFFCE5A8B)
                    )
                )
            )
        ) { club ->

            ClubCard(
                club = club
            )

            Spacer(
                modifier = Modifier.height(15.dp)
            )
        }
    }
}

// =====================================================
// PROFILE
// =====================================================

@Composable
private fun ProfileContent(
    studentName: String,
    email: String,
    onSettings: () -> Unit,
    onLogout: () -> Unit
) {

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            horizontal = 20.dp,
            vertical = 25.dp
        )
    ) {

        item {

            Text(
                text = "Profile",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = DarkText
            )

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp)
            ) {

                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Box(
                        modifier = Modifier
                            .size(85.dp)
                            .clip(CircleShape)
                            .background(LightBlue),
                        contentAlignment = Alignment.Center
                    ) {

                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = SkyBlue,
                            modifier = Modifier.size(48.dp)
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(12.dp)
                    )

                    Text(
                        text = studentName,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkText
                    )

                    Text(
                        text = email,
                        fontSize = 12.sp,
                        color = SoftText
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(18.dp)
            )

            ProfileOption(
                icon = Icons.Default.Person,
                title = "Edit Profile",
                subtitle = "Update your student information"
            )

            ProfileOption(
                icon = Icons.Default.Notifications,
                title = "Notifications",
                subtitle = "Manage event notifications"
            )

            ProfileOption(
                icon = Icons.Default.Settings,
                title = "Settings",
                subtitle = "App preferences and privacy",
                onClick = onSettings
            )

            ProfileOption(
                icon = Icons.Default.Logout,
                title = "Logout",
                subtitle = "Sign out from EventPulse",
                onClick = onLogout
            )
        }
    }
}

// =====================================================
// PROFILE OPTION
// =====================================================

@Composable
private fun ProfileOption(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit = {}
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .clickable {
                onClick()
            },
        shape = RoundedCornerShape(18.dp)
    ) {

        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier
                    .size(45.dp)
                    .clip(CircleShape)
                    .background(LightBlue),
                contentAlignment = Alignment.Center
            ) {

                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = SkyBlue
                )
            }

            Spacer(
                modifier = Modifier.width(14.dp)
            )

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    color = DarkText
                )

                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = SoftText
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = SoftText
            )
        }
    }
}

// =====================================================
// SETTINGS
// =====================================================

@Composable
private fun SettingsDialog(
    onDismiss: () -> Unit
) {

    AlertDialog(
        onDismissRequest = onDismiss,

        title = {
            Text(
                text = "Settings",
                fontWeight = FontWeight.ExtraBold
            )
        },

        text = {

            Column {

                Text(
                    text = "Account & Privacy",
                    fontWeight = FontWeight.Bold,
                    color = DarkText
                )

                Spacer(
                    modifier = Modifier.height(14.dp)
                )

                Text(
                    text = "Notifications",
                    color = SoftText
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Text(
                    text = "Privacy",
                    color = SoftText
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Text(
                    text = "About EventPulse",
                    color = SoftText
                )
            }
        },

        confirmButton = {
            TextButton(
                onClick = onDismiss
            ) {
                Text(
                    text = "Done",
                    color = SkyBlue,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    )
}

// =====================================================
// CHATBOT FLOATING BUTTON
// =====================================================

@Composable
private fun ChatbotFloatingButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {

    val infiniteTransition = rememberInfiniteTransition(
        label = "chatbot"
    )

    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chatScale"
    )

    Box(
        modifier = modifier
            .size(58.dp)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    listOf(
                        SkyBlue,
                        SkyBlueDark
                    )
                )
            )
            .clickable {
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {

        Icon(
            imageVector = Icons.Default.Chat,
            contentDescription = "AI Assistant",
            tint = White,
            modifier = Modifier
                .size(27.dp)
                .then(
                    Modifier
                        .size((27 * scale).dp)
                )
        )
    }
}

// =====================================================
// BOTTOM NAVIGATION
// =====================================================

@Composable
private fun BottomNavigationBar(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {

    val items = listOf(
        Triple(
            "Home",
            Icons.Default.Home,
            0
        ),
        Triple(
            "Explore",
            Icons.Default.Explore,
            1
        ),
        Triple(
            "My Events",
            Icons.Default.CalendarMonth,
            2
        ),
        Triple(
            "Clubs",
            Icons.Default.Group,
            3
        ),
        Triple(
            "Profile",
            Icons.Default.Person,
            4
        )
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = White,
        shadowElevation = 10.dp
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(
                    horizontal = 8.dp,
                    vertical = 7.dp
                ),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {

            items.forEach { item ->

                val selected = selectedTab == item.third

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            onTabSelected(item.third)
                        },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Icon(
                        imageVector = item.second,
                        contentDescription = item.first,
                        tint = if (selected)
                            SkyBlue
                        else
                            SoftText,
                        modifier = Modifier.size(23.dp)
                    )

                    Spacer(
                        modifier = Modifier.height(3.dp)
                    )

                    Text(
                        text = item.first,
                        fontSize = 9.sp,
                        fontWeight = if (selected)
                            FontWeight.Bold
                        else
                            FontWeight.Medium,
                        color = if (selected)
                            SkyBlue
                        else
                            SoftText
                    )
                }
            }
        }
    }
}
