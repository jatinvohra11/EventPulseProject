package com.eventpulse.app.ui.screens.login

import android.util.Patterns

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.FirebaseNetworkException
import kotlinx.coroutines.delay


// ============================================================
// EVENTPULSE COLORS
// ============================================================

private val OffWhite = Color(0xFFF8FAFC)
private val SkyBlue = Color(0xFF0797D1)
private val SkyBlueDark = Color(0xFF087EAE)
private val DarkText = Color(0xFF172033)
private val SoftText = Color(0xFF64748B)
private val BorderGrey = Color(0xFFD8E1EA)
private val White = Color.White
private val ErrorRed = Color(0xFFD32F2F)
private val SuccessGreen = Color(0xFF2E7D32)


// ============================================================
// ORGANIZER REGISTRATION SCREEN
// ============================================================

@Composable
fun OrganizerRegistrationScreen(
    onBack: () -> Unit = {},
    onRegistrationComplete: () -> Unit = {}
) {

    // --------------------------------------------------------
    // FORM STATES
    // --------------------------------------------------------

    var organizationName by remember {
        mutableStateOf("")
    }

    var organizerName by remember {
        mutableStateOf("")
    }

    var email by remember {
        mutableStateOf("")
    }

    var phone by remember {
        mutableStateOf("")
    }

    var organizationType by remember {
        mutableStateOf("")
    }

    var password by remember {
        mutableStateOf("")
    }

    var confirmPassword by remember {
        mutableStateOf("")
    }

    var passwordVisible by remember {
        mutableStateOf(false)
    }

    var confirmPasswordVisible by remember {
        mutableStateOf(false)
    }

    var showContent by remember {
        mutableStateOf(false)
    }

    // --------------------------------------------------------
    // FIREBASE / UI STATES
    // --------------------------------------------------------

    var isLoading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    var successMessage by remember {
        mutableStateOf("")
    }

    val auth = remember {
        FirebaseAuth.getInstance()
    }


    // --------------------------------------------------------
    // SCREEN ENTRY ANIMATION
    // --------------------------------------------------------

    LaunchedEffect(Unit) {
        delay(100)
        showContent = true
    }


    // --------------------------------------------------------
    // EVENTPULSE LOGO PULSE
    // --------------------------------------------------------

    val infiniteTransition = rememberInfiniteTransition(
        label = "organizerRegistrationLogo"
    )

    val logoScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1300,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "organizerRegistrationLogoScale"
    )


    // --------------------------------------------------------
    // MAIN SCREEN
    // --------------------------------------------------------

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    horizontal = 24.dp,
                    vertical = 18.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


            // ====================================================
            // TOP BAR
            // ====================================================

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(
                    animationSpec = tween(500)
                ) + slideInVertically(
                    initialOffsetY = { -20 },
                    animationSpec = tween(500)
                )
            ) {

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(45.dp),
                    contentAlignment = Alignment.CenterStart
                ) {

                    Text(
                        text = "‹  Back",
                        color = SkyBlue,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clickable {
                                if (!isLoading) {
                                    onBack()
                                }
                            }
                            .padding(
                                horizontal = 6.dp,
                                vertical = 8.dp
                            )
                    )
                }
            }


            Spacer(
                modifier = Modifier.height(8.dp)
            )


            // ====================================================
            // EVENTPULSE BRAND
            // ====================================================

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(
                    animationSpec = tween(
                        durationMillis = 650,
                        delayMillis = 100
                    )
                ) + slideInVertically(
                    initialOffsetY = { -25 },
                    animationSpec = tween(
                        durationMillis = 650,
                        delayMillis = 100
                    )
                )
            ) {

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text(
                        text = "EventPulse",
                        modifier = Modifier.scale(logoScale),
                        color = SkyBlue,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = (-0.8).sp
                    )

                    Spacer(
                        modifier = Modifier.height(4.dp)
                    )

                    Text(
                        text = "DISCOVER  •  PLAN  •  BELONG",
                        color = SoftText,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 2.2.sp
                    )
                }
            }


            Spacer(
                modifier = Modifier.height(24.dp)
            )


            // ====================================================
            // REGISTRATION CONTENT
            // ====================================================

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(
                    animationSpec = tween(
                        durationMillis = 700,
                        delayMillis = 250
                    )
                ) + slideInVertically(
                    initialOffsetY = { 35 },
                    animationSpec = tween(
                        durationMillis = 700,
                        delayMillis = 250
                    )
                )
            ) {

                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {


                    // ====================================================
                    // TITLE
                    // ====================================================

                    Text(
                        text = "Create Organizer Account",
                        color = DarkText,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(
                        modifier = Modifier.height(6.dp)
                    )

                    Text(
                        text = "Create and manage events on your campus",
                        color = SoftText,
                        fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth()
                    )


                    Spacer(
                        modifier = Modifier.height(24.dp)
                    )


                    // ====================================================
                    // ORGANIZATION NAME
                    // ====================================================

                    Text(
                        text = "Organization Name",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = organizationName,
                        onValueChange = {
                            organizationName = it
                            errorMessage = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter club or organization name",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // ORGANIZER NAME
                    // ====================================================

                    Text(
                        text = "Organizer Name",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = organizerName,
                        onValueChange = {
                            organizerName = it
                            errorMessage = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your full name",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // ORGANIZER EMAIL
                    // ====================================================

                    Text(
                        text = "Organizer Email",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            errorMessage = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your organizer email",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // PHONE NUMBER
                    // ====================================================

                    Text(
                        text = "Phone Number",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = {
                            phone = it
                            errorMessage = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your phone number",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Phone
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // ORGANIZATION TYPE
                    // ====================================================

                    Text(
                        text = "Organization Type",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = organizationType,
                        onValueChange = {
                            organizationType = it
                            errorMessage = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "e.g. Club, Society, Department",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // PASSWORD
                    // ====================================================

                    Text(
                        text = "Password",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Create a strong password",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        visualTransformation =
                            if (passwordVisible) {
                                VisualTransformation.None
                            } else {
                                PasswordVisualTransformation()
                            },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password
                        ),
                        trailingIcon = {

                            Text(
                                text = if (passwordVisible) {
                                    "HIDE"
                                } else {
                                    "SHOW"
                                },
                                color = SkyBlue,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        passwordVisible =
                                            !passwordVisible
                                    }
                                    .padding(
                                        horizontal = 8.dp
                                    )
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // CONFIRM PASSWORD
                    // ====================================================

                    Text(
                        text = "Confirm Password",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = {
                            confirmPassword = it
                            errorMessage = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Re-enter your password",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        visualTransformation =
                            if (confirmPasswordVisible) {
                                VisualTransformation.None
                            } else {
                                PasswordVisualTransformation()
                            },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password
                        ),
                        trailingIcon = {

                            Text(
                                text = if (confirmPasswordVisible) {
                                    "HIDE"
                                } else {
                                    "SHOW"
                                },
                                color = SkyBlue,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        confirmPasswordVisible =
                                            !confirmPasswordVisible
                                    }
                                    .padding(
                                        horizontal = 8.dp
                                    )
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // ERROR MESSAGE
                    // ====================================================

                    if (errorMessage.isNotEmpty()) {

                        Text(
                            text = errorMessage,
                            color = ErrorRed,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    bottom = 7.dp
                                )
                        )
                    }


                    // ====================================================
                    // SUCCESS MESSAGE
                    // ====================================================

                    if (successMessage.isNotEmpty()) {

                        Text(
                            text = successMessage,
                            color = SuccessGreen,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    bottom = 7.dp
                                )
                        )
                    }


                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )


                    // ====================================================
                    // CREATE ACCOUNT BUTTON
                    // ====================================================

                    Button(
                        onClick = {

                            errorMessage = ""
                            successMessage = ""

                            when {

                                organizationName.isBlank() -> {
                                    errorMessage =
                                        "Please enter organization name"
                                }

                                organizerName.isBlank() -> {
                                    errorMessage =
                                        "Please enter organizer name"
                                }

                                email.isBlank() -> {
                                    errorMessage =
                                        "Please enter organizer email"
                                }

                                !Patterns.EMAIL_ADDRESS
                                    .matcher(email.trim())
                                    .matches() -> {

                                    errorMessage =
                                        "Please enter a valid email address"
                                }

                                phone.isBlank() -> {
                                    errorMessage =
                                        "Please enter phone number"
                                }

                                organizationType.isBlank() -> {
                                    errorMessage =
                                        "Please enter organization type"
                                }

                                password.length < 6 -> {
                                    errorMessage =
                                        "Password must be at least 6 characters"
                                }

                                password != confirmPassword -> {
                                    errorMessage =
                                        "Passwords do not match"
                                }

                                else -> {

                                    isLoading = true

                                    auth.createUserWithEmailAndPassword(
                                        email.trim(),
                                        password
                                    ).addOnCompleteListener { task ->

                                        isLoading = false

                                        if (task.isSuccessful) {

                                            successMessage =
                                                "Organizer account created successfully!"

                                            // Firebase user created successfully.
                                            // Go back to Organizer Login.
                                            onRegistrationComplete()

                                        } else {

                                            errorMessage =
                                                when (task.exception) {

                                                    is FirebaseAuthUserCollisionException -> {
                                                        "An account already exists with this email."
                                                    }

                                                    is FirebaseAuthInvalidCredentialsException -> {
                                                        "Invalid email or password."
                                                    }

                                                    is FirebaseNetworkException -> {
                                                        "Network error. Please check your internet connection."
                                                    }

                                                    else -> {
                                                        task.exception?.message
                                                            ?: "Registration failed. Please try again."
                                                    }
                                                }
                                        }
                                    }
                                }
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SkyBlue,
                            contentColor = White,
                            disabledContainerColor = SkyBlue.copy(
                                alpha = 0.55f
                            ),
                            disabledContentColor = White
                        ),
                        elevation = ButtonDefaults.buttonElevation(
                            defaultElevation = 5.dp,
                            pressedElevation = 1.dp
                        )
                    ) {

                        Text(
                            text = if (isLoading) {
                                "Creating Account..."
                            } else {
                                "Create Organizer Account"
                            },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }


                    Spacer(
                        modifier = Modifier.height(20.dp)
                    )


                    // ====================================================
                    // DIVIDER
                    // ====================================================

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = BorderGrey
                        )

                        Text(
                            text = "  OR  ",
                            color = SoftText,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium
                        )

                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = BorderGrey
                        )
                    }


                    Spacer(
                        modifier = Modifier.height(18.dp)
                    )


                    // ====================================================
                    // GOOGLE REGISTRATION
                    // ====================================================

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .border(
                                width = 1.dp,
                                color = BorderGrey,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .background(
                                color = White,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable {
                                // Google registration will be connected later.
                            },
                        contentAlignment = Alignment.Center
                    ) {

                        Row(
                            horizontalArrangement =
                                Arrangement.Center,
                            verticalAlignment =
                                Alignment.CenterVertically
                        ) {

                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .border(
                                        width = 1.dp,
                                        color = BorderGrey,
                                        shape = RoundedCornerShape(50)
                                    ),
                                contentAlignment =
                                    Alignment.Center
                            ) {

                                Text(
                                    text = "G",
                                    color = SkyBlue,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(
                                modifier = Modifier.width(10.dp)
                            )

                            Text(
                                text = "Sign up with Google",
                                color = DarkText,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }


                    Spacer(
                        modifier = Modifier.height(18.dp)
                    )


                    // ====================================================
                    // LOGIN LINK
                    // ====================================================

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clickable {
                                if (!isLoading) {
                                    onBack()
                                }
                            },
                        horizontalArrangement =
                            Arrangement.Center,
                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {

                        Text(
                            text = "Already have an organizer account?",
                            color = SoftText,
                            fontSize = 11.sp
                        )

                        Spacer(
                            modifier = Modifier.width(5.dp)
                        )

                        Text(
                            text = "Login",
                            color = SkyBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // BOTTOM
                    // ====================================================

                    Text(
                        text = "ORGANIZER PORTAL  •  EVENTPULSE",
                        color = SoftText.copy(alpha = 0.55f),
                        fontSize = 8.sp,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(
                            bottom = 8.dp
                        )
                    )
                }
            }
        }
    }
}