package com.eventpulse.app.ui.screens.splash

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eventpulse.app.R
import com.eventpulse.app.ui.theme.EventPulseBackground
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin


@Composable
fun SplashScreen(
    onFinished: () -> Unit
) {

    var startAnimation by remember {
        mutableStateOf(false)
    }


    // ---------------------------------------------------------
    // LOGO ENTRANCE ANIMATION
    // ---------------------------------------------------------

    val logoScale by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.65f,
        animationSpec = tween(
            durationMillis = 1100,
            easing = FastOutSlowInEasing
        ),
        label = "logoScale"
    )

    val logoAlpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(
            durationMillis = 900
        ),
        label = "logoAlpha"
    )


    // ---------------------------------------------------------
    // CONTINUOUS ANIMATION
    // ---------------------------------------------------------

    val infiniteTransition = rememberInfiniteTransition(
        label = "splashAnimation"
    )


    // Small breathing effect for the logo
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1800,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )


    // Orbit rotation
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 9000
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )


    // Loading animation
    val loadingAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1100
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "loadingAlpha"
    )


    // ---------------------------------------------------------
    // SPLASH TIMER
    // ---------------------------------------------------------

    LaunchedEffect(Unit) {

        startAnimation = true

        delay(4000)

        onFinished()
    }


    // ---------------------------------------------------------
    // BACKGROUND
    // ---------------------------------------------------------

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF05020D),
                        EventPulseBackground,
                        Color(0xFF03010A)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {


        // -----------------------------------------------------
        // ORBIT / NEON BACKGROUND ANIMATION
        // -----------------------------------------------------

        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {

            val centerX = size.width / 2f
            val centerY = size.height * 0.40f


            // Soft purple glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF7C3CFF).copy(alpha = 0.16f),
                        Color.Transparent
                    ),
                    center = Offset(
                        centerX,
                        centerY
                    ),
                    radius = size.width * 0.38f
                ),
                radius = size.width * 0.38f,
                center = Offset(
                    centerX,
                    centerY
                )
            )


            // -------------------------------------------------
            // ORBIT RINGS
            // -------------------------------------------------

            val rings = listOf(
                0.18f,
                0.22f,
                0.27f,
                0.31f
            )


            rings.forEachIndexed { index, factor ->

                drawCircle(
                    color = Color(0xFF7C3CFF).copy(
                        alpha = if (index == 2) 0.32f else 0.14f
                    ),
                    radius = size.width * factor,
                    center = Offset(
                        centerX,
                        centerY
                    ),
                    style = Stroke(
                        width = if (index == 2) 1.8f else 1f
                    )
                )
            }


            // -------------------------------------------------
            // ROTATING NEON ARC
            // -------------------------------------------------

            val arcRadius = size.width * 0.27f

            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        Color(0xFF6D28FF),
                        Color(0xFFD946EF),
                        Color(0xFFFF9D35),
                        Color.Transparent,
                        Color(0xFF6D28FF)
                    )
                ),
                startAngle = rotation,
                sweepAngle = 110f,
                useCenter = false,
                topLeft = Offset(
                    centerX - arcRadius,
                    centerY - arcRadius
                ),
                size = Size(
                    arcRadius * 2,
                    arcRadius * 2
                ),
                style = Stroke(
                    width = 4f,
                    cap = StrokeCap.Round
                )
            )


            // -------------------------------------------------
            // FLOATING NEON DOTS
            // -------------------------------------------------

            val orbitRadius = size.width * 0.30f

            val angles = listOf(
                rotation,
                rotation + 120f,
                rotation + 240f
            )


            angles.forEachIndexed { index, angle ->

                val radians = Math.toRadians(
                    angle.toDouble()
                )


                val x = centerX +
                        cos(radians).toFloat() * orbitRadius


                val y = centerY +
                        sin(radians).toFloat() * orbitRadius


                val dotColor = when (index) {

                    0 -> Color(0xFFE93DFF)

                    1 -> Color(0xFFFF9D35)

                    else -> Color(0xFF7C4DFF)
                }


                // Glow
                drawCircle(
                    color = dotColor.copy(alpha = 0.15f),
                    radius = 13f,
                    center = Offset(x, y)
                )


                // Dot
                drawCircle(
                    color = dotColor,
                    radius = 4.5f,
                    center = Offset(x, y)
                )
            }
        }


        // -----------------------------------------------------
        // MAIN CONTENT
        // -----------------------------------------------------

        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


            // -------------------------------------------------
            // LOGO AREA
            // -------------------------------------------------

            Box(
                modifier = Modifier
                    .size(250.dp)
                    .scale(logoScale)
                    .alpha(logoAlpha),
                contentAlignment = Alignment.Center
            ) {


                // -------------------------------------------------
                // SOFT GLOW BEHIND LOGO
                // -------------------------------------------------

                Canvas(
                    modifier = Modifier
                        .size(200.dp)
                        .scale(pulse)
                ) {

                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF7C3CFF).copy(alpha = 0.28f),
                                Color(0xFFD946EF).copy(alpha = 0.10f),
                                Color.Transparent
                            )
                        ),
                        radius = size.minDimension / 2f
                    )
                }


                // -------------------------------------------------
                // CIRCULAR LOGO
                // -------------------------------------------------

                Image(
                    painter = painterResource(
                        id = R.drawable.eventpulse_logo
                    ),
                    contentDescription = "EventPulse Logo",
                    modifier = Modifier
                        .size(165.dp)
                        .scale(pulse)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            }


            // -------------------------------------------------
            // SPACE BEFORE LOADING
            // -------------------------------------------------

            Spacer(
                modifier = Modifier.height(70.dp)
            )


            // -------------------------------------------------
            // LOADING BAR
            // -------------------------------------------------

            Canvas(
                modifier = Modifier
                    .size(
                        width = 150.dp,
                        height = 6.dp
                    )
                    .alpha(loadingAlpha)
            ) {


                // Track
                drawRoundRect(
                    color = Color(0xFF6D28FF).copy(
                        alpha = 0.22f
                    ),
                    size = size,
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(
                        10f,
                        10f
                    )
                )


                // Neon progress
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFFD946EF),
                            Color(0xFF8B5CF6),
                            Color(0xFFFF9D35)
                        )
                    ),
                    size = Size(
                        width = size.width * 0.58f,
                        height = size.height
                    ),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(
                        10f,
                        10f
                    )
                )
            }


            Spacer(
                modifier = Modifier.height(16.dp)
            )


            // -------------------------------------------------
            // LOADING TEXT
            // -------------------------------------------------

            Text(
                text = "L O A D I N G   C A M P U S   V I B E S . . .",
                color = Color.White.copy(alpha = 0.68f),
                fontSize = 9.sp,
                letterSpacing = 2.sp,
                modifier = Modifier.alpha(loadingAlpha)
            )
        }
    }
}