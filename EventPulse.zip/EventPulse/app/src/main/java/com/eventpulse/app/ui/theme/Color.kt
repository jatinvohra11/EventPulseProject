package com.eventpulse.app.ui.theme

import androidx.compose.ui.graphics.Color

// ================================
// EventPulse - OFF WHITE + SKY BLUE
// ================================

// Backgrounds
val EventPulseBackground = Color(0xFFF8FAFC)
val EventPulseSurface = Color(0xFFFFFFFF)
val EventPulseSurfaceSoft = Color(0xFFF1F5F9)

// Primary Sky Blue
val EventPulseSkyBlue = Color(0xFF38BDF8)
val EventPulseSkyBlueDark = Color(0xFF0284C7)
val EventPulseSkyBlueLight = Color(0xFFBAE6FD)

// Text
val EventPulseTextPrimary = Color(0xFF0F172A)
val EventPulseTextSecondary = Color(0xFF64748B)
val EventPulseTextMuted = Color(0xFF94A3B8)

// Borders
val EventPulseBorder = Color(0xFFE2E8F0)

// Status
val EventPulseSuccess = Color(0xFF22C55E)
val EventPulseError = Color(0xFFEF4444)