package com.eventpulse.app.ui.screens.login

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import com.google.firebase.auth.FirebaseAuth


// ============================================================
// EVENTPULSE STUDENT REGISTRATION
// ============================================================

private val OffWhite = Color(0xFFF8FAFC)
private val SkyBlue = Color(0xFF0B9DD1)
private val SkyBlueDark = Color(0xFF087EAB)
private val DarkText = Color(0xFF172033)
private val SoftText = Color(0xFF64748B)
private val BorderGrey = Color(0xFFD8E1EA)
private val White = Color.White


// ============================================================
// STUDENT REGISTRATION SCREEN
// ============================================================

@Composable
fun StudentRegistrationScreen(
    onBack: () -> Unit = {},
    onRegistrationComplete: () -> Unit = {}
) {

    // --------------------------------------------------------
    // FORM STATES
    // --------------------------------------------------------

    var fullName by remember {
        mutableStateOf("")
    }

    var email by remember {
        mutableStateOf("")
    }

    var collegeId by remember {
        mutableStateOf("")
    }

    var password by remember {
        mutableStateOf("")
    }

    var confirmPassword by remember {
        mutableStateOf("")
    }

    var passwordVisible by remember {
        mutableStateOf(false)
    }

    var confirmPasswordVisible by remember {
        mutableStateOf(false)
    }

    var showContent by remember {
        mutableStateOf(false)
    }

    // --------------------------------------------------------
    // FIREBASE AUTHENTICATION STATES
    // --------------------------------------------------------

    val auth = remember {
        FirebaseAuth.getInstance()
    }

    var isLoading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf("")
    }


    // --------------------------------------------------------
    // SCREEN ENTRY ANIMATION
    // --------------------------------------------------------

    LaunchedEffect(Unit) {
        delay(100)
        showContent = true
    }


    // --------------------------------------------------------
    // EVENTPULSE LOGO PULSE
    // --------------------------------------------------------

    val infiniteTransition = rememberInfiniteTransition(
        label = "registrationLogo"
    )

    val logoScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.035f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1300,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "registrationLogoScale"
    )


    // --------------------------------------------------------
    // MAIN SCREEN
    // --------------------------------------------------------

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    horizontal = 24.dp,
                    vertical = 18.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {


            // ====================================================
            // TOP BAR
            // ====================================================

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(
                    animationSpec = tween(500)
                ) + slideInVertically(
                    initialOffsetY = { -20 },
                    animationSpec = tween(500)
                )
            ) {

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(45.dp),
                    contentAlignment = Alignment.CenterStart
                ) {

                    Text(
                        text = "‹  Back",
                        color = SkyBlue,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clickable {
                                onBack()
                            }
                            .padding(
                                horizontal = 6.dp,
                                vertical = 8.dp
                            )
                    )
                }
            }


            Spacer(
                modifier = Modifier.height(8.dp)
            )


            // ====================================================
            // EVENTPULSE BRAND
            // ====================================================

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(
                    animationSpec = tween(
                        durationMillis = 650,
                        delayMillis = 100
                    )
                ) + slideInVertically(
                    initialOffsetY = { -25 },
                    animationSpec = tween(
                        durationMillis = 650,
                        delayMillis = 100
                    )
                )
            ) {

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Text(
                        text = "EventPulse",
                        modifier = Modifier.scale(logoScale),
                        color = SkyBlue,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = (-0.8).sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(
                        modifier = Modifier.height(4.dp)
                    )

                    Text(
                        text = "DISCOVER  •  PLAN  •  BELONG",
                        color = SoftText,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 2.2.sp
                    )
                }
            }


            Spacer(
                modifier = Modifier.height(25.dp)
            )


            // ====================================================
            // REGISTRATION CONTENT
            // ====================================================

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(
                    animationSpec = tween(
                        durationMillis = 700,
                        delayMillis = 250
                    )
                ) + slideInVertically(
                    initialOffsetY = { 35 },
                    animationSpec = tween(
                        durationMillis = 700,
                        delayMillis = 250
                    )
                )
            ) {

                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {


                    // ====================================================
                    // TITLE
                    // ====================================================

                    Text(
                        text = "Create Student Account",
                        color = DarkText,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(
                        modifier = Modifier.height(6.dp)
                    )

                    Text(
                        text = "Join your campus community on EventPulse",
                        color = SoftText,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )


                    Spacer(
                        modifier = Modifier.height(24.dp)
                    )


                    // ====================================================
                    // FULL NAME
                    // ====================================================

                    Text(
                        text = "Full Name",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = fullName,
                        onValueChange = {
                            fullName = it
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your full name",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // STUDENT EMAIL
                    // ====================================================

                    Text(
                        text = "Student Email",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your university email",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Email
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // STUDENT ID
                    // ====================================================

                    Text(
                        text = "Student ID",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = collegeId,
                        onValueChange = {
                            collegeId = it
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your student ID",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text
                        ),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // PASSWORD
                    // ====================================================

                    Text(
                        text = "Password",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Create a strong password",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        visualTransformation =
                            if (passwordVisible) {
                                VisualTransformation.None
                            } else {
                                PasswordVisualTransformation()
                            },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password
                        ),
                        trailingIcon = {

                            Text(
                                text = if (passwordVisible) {
                                    "HIDE"
                                } else {
                                    "SHOW"
                                },
                                color = SkyBlue,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        passwordVisible =
                                            !passwordVisible
                                    }
                                    .padding(
                                        horizontal = 8.dp
                                    )
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(15.dp)
                    )


                    // ====================================================
                    // CONFIRM PASSWORD
                    // ====================================================

                    Text(
                        text = "Confirm Password",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(7.dp)
                    )

                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = {
                            confirmPassword = it
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Re-enter your password",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        visualTransformation =
                            if (confirmPasswordVisible) {
                                VisualTransformation.None
                            } else {
                                PasswordVisualTransformation()
                            },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password
                        ),
                        trailingIcon = {

                            Text(
                                text = if (confirmPasswordVisible) {
                                    "HIDE"
                                } else {
                                    "SHOW"
                                },
                                color = SkyBlue,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        confirmPasswordVisible =
                                            !confirmPasswordVisible
                                    }
                                    .padding(
                                        horizontal = 8.dp
                                    )
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = White,
                            unfocusedContainerColor = White,
                            cursorColor = SkyBlue,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText
                        ),
                        textStyle = TextStyle(
                            fontSize = 14.sp
                        )
                    )


                    Spacer(
                        modifier = Modifier.height(22.dp)
                    )


                    // ====================================================
                    // REGISTER BUTTON
                    // ====================================================

                    Button(
                        onClick = {

                            errorMessage = ""

                            when {
                                fullName.trim().isEmpty() -> {
                                    errorMessage = "Please enter your full name"
                                }

                                email.trim().isEmpty() -> {
                                    errorMessage = "Please enter your student email"
                                }

                                collegeId.trim().isEmpty() -> {
                                    errorMessage = "Please enter your student ID"
                                }

                                password.length < 6 -> {
                                    errorMessage = "Password must be at least 6 characters"
                                }

                                password != confirmPassword -> {
                                    errorMessage = "Passwords do not match"
                                }

                                else -> {
                                    isLoading = true

                                    auth.createUserWithEmailAndPassword(
                                        email.trim(),
                                        password
                                    ).addOnCompleteListener { task ->

                                        isLoading = false

                                        if (task.isSuccessful) {
                                            onRegistrationComplete()
                                        } else {
                                            errorMessage =
                                                task.exception?.message
                                                    ?: "Registration failed. Please try again."
                                        }
                                    }
                                }
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SkyBlue,
                            contentColor = White
                        ),
                        elevation = ButtonDefaults.buttonElevation(
                            defaultElevation = 5.dp,
                            pressedElevation = 1.dp
                        )
                    ) {

                        Text(
                            text = if (isLoading) {
                                "Creating Account..."
                            } else {
                                "Create Student Account"
                            },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (errorMessage.isNotEmpty()) {
                        Spacer(
                            modifier = Modifier.height(8.dp)
                        )

                        Text(
                            text = errorMessage,
                            color = Color(0xFFD32F2F),
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(20.dp)
                    )


                    // ====================================================
                    // DIVIDER
                    // ====================================================

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = BorderGrey
                        )

                        Text(
                            text = "  OR  ",
                            color = SoftText,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium
                        )

                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = BorderGrey
                        )
                    }


                    Spacer(
                        modifier = Modifier.height(18.dp)
                    )


                    // ====================================================
                    // GOOGLE REGISTRATION
                    // ====================================================

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .border(
                                width = 1.dp,
                                color = BorderGrey,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .background(
                                color = White,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable {
                                // Google registration later
                            },
                        contentAlignment = Alignment.Center
                    ) {

                        Row(
                            horizontalArrangement =
                                Arrangement.Center,
                            verticalAlignment =
                                Alignment.CenterVertically
                        ) {

                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .border(
                                        width = 1.dp,
                                        color = BorderGrey,
                                        shape = RoundedCornerShape(50)
                                    ),
                                contentAlignment =
                                    Alignment.Center
                            ) {

                                Text(
                                    text = "G",
                                    color = SkyBlue,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(
                                modifier = Modifier.width(10.dp)
                            )

                            Text(
                                text = "Sign up with Google",
                                color = DarkText,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }


                    Spacer(
                        modifier = Modifier.height(18.dp)
                    )


                    // ====================================================
                    // LOGIN LINK
                    // ====================================================

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement =
                            Arrangement.Center,
                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {

                        Text(
                            text = "Already have an account?",
                            color = SoftText,
                            fontSize = 11.sp
                        )

                        Spacer(
                            modifier = Modifier.width(5.dp)
                        )

                        Text(
                            text = "Login",
                            color = SkyBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                onBack()
                            }
                        )
                    }
                }
            }


            // ====================================================
            // BOTTOM
            // ====================================================

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            Text(
                text = "STUDENT PORTAL  •  EVENTPULSE",
                color = SoftText.copy(alpha = 0.55f),
                fontSize = 8.sp,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(
                    bottom = 4.dp
                )
            )
        }
    }
}
