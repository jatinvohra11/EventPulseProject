package com.eventpulse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

import com.eventpulse.app.ui.screens.login.OrganizerLoginScreen
import com.eventpulse.app.ui.screens.login.StudentLoginScreen
import com.eventpulse.app.ui.screens.login.OrganizerRegistrationScreen
import com.eventpulse.app.ui.screens.login.StudentRegistrationScreen
import com.eventpulse.app.ui.theme.EventPulseTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            EventPulseTheme {

                var currentScreen by remember {
                    mutableStateOf("login")
                }

                when (currentScreen) {

                    // ==============================
                    // STUDENT LOGIN
                    // ==============================

                    "login" -> {

                        StudentLoginScreen(

                            onLogin = {
                                // TODO: Add student login functionality
                            },

                            onGoogleLogin = {
                                // TODO: Add student Google login
                            },

                            onCreateAccount = {
                                currentScreen = "student_registration"
                            },

                            onOrganizerLogin = {
                                currentScreen = "organizer_login"
                            }
                        )
                    }


                    // ==============================
                    // STUDENT REGISTRATION
                    // ==============================

                    "student_registration" -> {

                        StudentRegistrationScreen(

                            onBack = {
                                currentScreen = "login"
                            },

                            onRegistrationComplete = {
                                currentScreen = "login"
                            }
                        )
                    }


                    // ==============================
                    // ORGANIZER LOGIN
                    // ==============================

                    "organizer_login" -> {

                        OrganizerLoginScreen(

                            onLogin = {
                                // TODO: Add organizer login functionality
                            },

                            onGoogleLogin = {
                                // TODO: Add organizer Google login
                            },

                            onCreateAccount = {
                                // Organizer Registration
                                // Will be connected in next step
                                currentScreen = "organizer_registration"
                            },

                            onBack = {
                                // Back to Student Login
                                currentScreen = "login"
                            }
                        )
                    }


                    // ==============================
                    // ORGANIZER REGISTRATION
                    // ==============================

                    "organizer_registration" -> {

                        OrganizerRegistrationScreen(

                            onBack = {
                                currentScreen = "organizer_login"
                            },

                            onRegistrationComplete = {
                                currentScreen = "organizer_login"
                            }
                        )
                    }
                }
            }
        }
    }
}