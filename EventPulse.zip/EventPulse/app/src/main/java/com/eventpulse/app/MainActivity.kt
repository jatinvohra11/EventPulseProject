package com.eventpulse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.eventpulse.app.ui.screens.login.StudentLoginScreen
import com.eventpulse.app.ui.screens.login.StudentRegistrationScreen
import com.eventpulse.app.ui.theme.EventPulseTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            EventPulseTheme {

                var currentScreen by remember {
                    mutableStateOf("login")
                }

                when (currentScreen) {

                    // ==============================
                    // STUDENT LOGIN
                    // ==============================

                    "login" -> {

                        StudentLoginScreen(
                            onLogin = {
                                // TODO: Add login functionality
                            },

                            onGoogleLogin = {
                                // TODO: Add Google login
                            },

                            onCreateAccount = {
                                // Open Student Registration
                                currentScreen = "student_registration"
                            }
                        )
                    }

                    // ==============================
                    // STUDENT REGISTRATION
                    // ==============================

                    "student_registration" -> {

                        StudentRegistrationScreen(
                            onBack = {
                                // Go back to Login
                                currentScreen = "login"
                            },

                            onRegistrationComplete = {
                                // After successful registration
                                currentScreen = "login"
                            }
                        )
                    }
                }
            }
        }
    }
}