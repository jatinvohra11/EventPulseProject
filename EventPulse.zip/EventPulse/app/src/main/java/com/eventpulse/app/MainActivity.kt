package com.eventpulse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eventpulse.app.ui.screens.home.StudentHomeScreen
import com.eventpulse.app.ui.screens.login.OrganizerLoginScreen
import com.eventpulse.app.ui.screens.login.OrganizerRegistrationScreen
import com.eventpulse.app.ui.screens.login.StudentLoginScreen
import com.eventpulse.app.ui.screens.login.StudentRegistrationScreen
import com.eventpulse.app.ui.theme.EventPulseTheme
import com.google.firebase.auth.FirebaseAuth


// ================================================================
// EVENTPULSE COLORS
// ================================================================

private val OffWhite = Color(0xFFF8FAFC)
private val SkyBlue = Color(0xFF0797D1)
private val DarkText = Color(0xFF172033)
private val SoftText = Color(0xFF64748B)


class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            EventPulseTheme {

                // ====================================================
                // CURRENT SCREEN
                // ====================================================

                var currentScreen by remember {
                    mutableStateOf("login")
                }


                // ====================================================
                // FIREBASE CURRENT USER
                // ====================================================

                val currentUser = FirebaseAuth
                    .getInstance()
                    .currentUser


                // ====================================================
                // STUDENT NAME
                //
                // Firebase displayName
                //        ↓
                // Email before @
                //        ↓
                // Student
                // ====================================================

                val studentName =
                    currentUser?.displayName
                        ?.takeIf { it.isNotBlank() }
                        ?: currentUser?.email
                            ?.substringBefore("@")
                            ?.substringBefore(".")
                            ?.replaceFirstChar {
                                it.uppercase()
                            }
                        ?: "Student"


                // ====================================================
                // SCREEN NAVIGATION
                // ====================================================

                when (currentScreen) {


                    // ==================================================
                    // STUDENT LOGIN
                    // ==================================================

                    "login" -> {

                        StudentLoginScreen(

                            onLogin = {

                                // Firebase login successful
                                currentScreen = "student_home"
                            },


                            onGoogleLogin = {

                                // Google login will be connected later
                                currentScreen = "student_home"
                            },


                            onCreateAccount = {

                                currentScreen =
                                    "student_registration"
                            },


                            onOrganizerLogin = {

                                currentScreen =
                                    "organizer_login"
                            }
                        )
                    }


                    // ==================================================
                    // STUDENT REGISTRATION
                    // ==================================================

                    "student_registration" -> {

                        StudentRegistrationScreen(

                            onBack = {

                                currentScreen = "login"
                            },


                            onRegistrationComplete = {

                                currentScreen = "login"
                            }
                        )
                    }


                    // ==================================================
                    // STUDENT HOME
                    // ==================================================

                    "student_home" -> {
                        StudentHomeScreen()
                    }


                    // ==================================================
                    // PROFILE
                    // ==================================================

                    "profile" -> {

                        SimplePage(

                            title = "Profile",

                            subtitle =
                                "Manage your EventPulse profile",

                            onBack = {

                                currentScreen =
                                    "student_home"
                            }
                        )
                    }


                    // ==================================================
                    // SETTINGS
                    // ==================================================

                    "settings" -> {

                        SimplePage(

                            title = "Settings",

                            subtitle =
                                "Manage your EventPulse settings",

                            onBack = {

                                currentScreen =
                                    "student_home"
                            }
                        )
                    }


                    // ==================================================
                    // EXPLORE
                    // ==================================================

                    "explore" -> {

                        SimplePage(

                            title = "Explore",

                            subtitle =
                                "Discover campus events, clubs and communities",

                            onBack = {

                                currentScreen =
                                    "student_home"
                            }
                        )
                    }


                    // ==================================================
                    // MY EVENTS
                    // ==================================================

                    "my_events" -> {

                        SimplePage(

                            title = "My Events",

                            subtitle =
                                "Your registered and saved events",

                            onBack = {

                                currentScreen =
                                    "student_home"
                            }
                        )
                    }


                    // ==================================================
                    // NOTIFICATIONS
                    // ==================================================

                    "notifications" -> {

                        SimplePage(

                            title = "Notifications",

                            subtitle =
                                "Your latest EventPulse notifications",

                            onBack = {

                                currentScreen =
                                    "student_home"
                            }
                        )
                    }


                    // ==================================================
                    // EVENT DETAILS
                    // ==================================================

                    "event_details" -> {

                        SimplePage(

                            title = "Event Details",

                            subtitle =
                                "Event details will appear here",

                            onBack = {

                                currentScreen =
                                    "student_home"
                            }
                        )
                    }


                    // ==================================================
                    // ORGANIZER LOGIN
                    // ==================================================

                    "organizer_login" -> {

                        OrganizerLoginScreen(

                            onLogin = {

                                // Organizer dashboard will be connected
                                // in the organizer phase.
                            },


                            onGoogleLogin = {

                                // Google organizer login later.
                            },


                            onCreateAccount = {

                                currentScreen =
                                    "organizer_registration"
                            },


                            onBack = {

                                currentScreen =
                                    "login"
                            }
                        )
                    }


                    // ==================================================
                    // ORGANIZER REGISTRATION
                    // ==================================================

                    "organizer_registration" -> {

                        OrganizerRegistrationScreen(

                            onBack = {

                                currentScreen =
                                    "organizer_login"
                            },


                            onRegistrationComplete = {

                                currentScreen =
                                    "organizer_login"
                            }
                        )
                    }
                }
            }
        }
    }
}


// ==================================================================
// TEMPORARY SIMPLE PAGE
// ==================================================================
//
// These pages are temporary placeholders.
// Later we will replace them with proper:
//
// ProfileScreen
// SettingsScreen
// ExploreScreen
// MyEventsScreen
// NotificationsScreen
// EventDetailsScreen
//
// ==================================================================

@androidx.compose.runtime.Composable
private fun SimplePage(
    title: String,
    subtitle: String,
    onBack: () -> Unit
) {

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),

            horizontalAlignment =
                Alignment.CenterHorizontally,

            verticalArrangement =
                Arrangement.Center
        ) {

            Text(
                text = title,
                color = DarkText,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )


            Spacer(
                modifier = Modifier.height(10.dp)
            )


            Text(
                text = subtitle,
                color = SoftText,
                fontSize = 15.sp
            )


            Spacer(
                modifier = Modifier.height(30.dp)
            )


            Text(
                text = "‹  Back to Home",
                color = SkyBlue,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,

                modifier = Modifier.clickable {

                    onBack()
                }
            )
        }
    }
}