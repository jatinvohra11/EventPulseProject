package com.eventpulse.app.ui.screens.login

import android.util.Patterns
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.FirebaseNetworkException

// ---------------------------------------------------------
// EVENTPULSE COLORS
// ---------------------------------------------------------

private val OffWhite = Color(0xFFF8FAFC)
private val SkyBlue = Color(0xFF0797D1)
private val SkyBlueDark = Color(0xFF087EAE)
private val DarkText = Color(0xFF172033)
private val SoftText = Color(0xFF64748B)
private val BorderGrey = Color(0xFFD8E1EA)
private val ErrorRed = Color(0xFFD32F2F)

// ---------------------------------------------------------
// ORGANIZER LOGIN SCREEN
// ---------------------------------------------------------

@Composable
fun OrganizerLoginScreen(
    onLogin: () -> Unit = {},
    onGoogleLogin: () -> Unit = {},
    onCreateAccount: () -> Unit = {},
    onBack: () -> Unit = {}
) {

    // -----------------------------------------------------
    // FIREBASE
    // -----------------------------------------------------

    val auth = remember {
        FirebaseAuth.getInstance()
    }

    // -----------------------------------------------------
    // FORM STATES
    // -----------------------------------------------------

    var email by remember {
        mutableStateOf("")
    }

    var password by remember {
        mutableStateOf("")
    }

    var passwordVisible by remember {
        mutableStateOf(false)
    }

    var showContent by remember {
        mutableStateOf(false)
    }

    var isLoading by remember {
        mutableStateOf(false)
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    var successMessage by remember {
        mutableStateOf("")
    }

    // -----------------------------------------------------
    // SCREEN ENTRY ANIMATION
    // -----------------------------------------------------

    LaunchedEffect(Unit) {
        showContent = true
    }

    // -----------------------------------------------------
    // LOGO ANIMATION
    // -----------------------------------------------------

    val logoScale by animateFloatAsState(
        targetValue = if (showContent) 1f else 0.85f,
        animationSpec = tween(
            durationMillis = 700,
            easing = FastOutSlowInEasing
        ),
        label = "organizerLogoScale"
    )

    // -----------------------------------------------------
    // LOGIN FUNCTION
    // -----------------------------------------------------

    fun loginOrganizer() {

        errorMessage = ""
        successMessage = ""

        val cleanEmail = email.trim()

        // Empty email
        if (cleanEmail.isEmpty()) {
            errorMessage = "Please enter your organizer email."
            return
        }

        // Invalid email
        if (!Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            errorMessage = "Please enter a valid email address."
            return
        }

        // Empty password
        if (password.isEmpty()) {
            errorMessage = "Please enter your password."
            return
        }

        isLoading = true

        auth.signInWithEmailAndPassword(
            cleanEmail,
            password
        ).addOnCompleteListener { task ->

            isLoading = false

            if (task.isSuccessful) {

                successMessage = "Login successful!"

                // Move to organizer dashboard
                onLogin()

            } else {

                errorMessage = when (task.exception) {

                    is com.google.firebase.auth.FirebaseAuthInvalidUserException ->
                        "No organizer account found with this email."

                    is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException ->
                        "Incorrect email or password."

                    is FirebaseNetworkException ->
                        "Network error. Please check your internet connection."

                    else ->
                        task.exception?.message
                            ?: "Login failed. Please try again."
                }
            }
        }
    }

    // -----------------------------------------------------
    // FORGOT PASSWORD
    // -----------------------------------------------------

    fun resetPassword() {

        errorMessage = ""
        successMessage = ""

        val cleanEmail = email.trim()

        if (cleanEmail.isEmpty()) {
            errorMessage = "Enter your organizer email first."
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            errorMessage = "Please enter a valid email address."
            return
        }

        isLoading = true

        auth.sendPasswordResetEmail(cleanEmail)
            .addOnCompleteListener { task ->

                isLoading = false

                if (task.isSuccessful) {

                    successMessage =
                        "Password reset email sent. Check your inbox."

                } else {

                    errorMessage = when (task.exception) {

                        is FirebaseNetworkException ->
                            "Network error. Please check your internet connection."

                        else ->
                            task.exception?.message
                                ?: "Unable to send reset email."
                    }
                }
            }
    }

    // -----------------------------------------------------
    // SCREEN
    // -----------------------------------------------------

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 28.dp,
                    vertical = 24.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // -------------------------------------------------
            // BACK BUTTON
            // -------------------------------------------------

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(45.dp),
                contentAlignment = Alignment.CenterStart
            ) {

                Text(
                    text = "‹  Back",
                    color = SkyBlue,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .clickable {
                            onBack()
                        }
                        .padding(
                            horizontal = 6.dp,
                            vertical = 8.dp
                        )
                )
            }

            Spacer(
                modifier = Modifier.height(14.dp)
            )

            // -------------------------------------------------
            // EVENTPULSE BRAND
            // -------------------------------------------------

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.scale(logoScale)
            ) {

                Text(
                    text = "EventPulse",
                    color = SkyBlue,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = (-0.8).sp
                )

                Spacer(
                    modifier = Modifier.height(5.dp)
                )

                Text(
                    text = "DISCOVER  •  PLAN  •  BELONG",
                    color = SoftText,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 2.2.sp
                )
            }

            Spacer(
                modifier = Modifier.height(38.dp)
            )

            // -------------------------------------------------
            // LOGIN CONTENT
            // -------------------------------------------------

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(
                    animationSpec = tween(700)
                ) + slideInVertically(
                    initialOffsetY = { 35 },
                    animationSpec = tween(
                        durationMillis = 700,
                        easing = FastOutSlowInEasing
                    )
                )
            ) {

                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {

                    // -------------------------------------------------
                    // TITLE
                    // -------------------------------------------------

                    Text(
                        text = "Organizer Login",
                        color = DarkText,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(
                        modifier = Modifier.height(6.dp)
                    )

                    Text(
                        text = "Manage your campus events with EventPulse",
                        color = SoftText,
                        fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(
                        modifier = Modifier.height(24.dp)
                    )

                    // -------------------------------------------------
                    // ORGANIZER EMAIL
                    // -------------------------------------------------

                    Text(
                        text = "Organizer Email",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            errorMessage = ""
                            successMessage = ""
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your organizer email",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText,
                            cursorColor = SkyBlue
                        )
                    )

                    Spacer(
                        modifier = Modifier.height(20.dp)
                    )

                    // -------------------------------------------------
                    // PASSWORD
                    // -------------------------------------------------

                    Text(
                        text = "Password",
                        color = DarkText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            errorMessage = ""
                            successMessage = ""
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp),
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "Enter your password",
                                color = SoftText.copy(alpha = 0.65f),
                                fontSize = 13.sp
                            )
                        },
                        visualTransformation = if (passwordVisible) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        trailingIcon = {

                            Text(
                                text = if (passwordVisible) {
                                    "HIDE"
                                } else {
                                    "SHOW"
                                },
                                color = SkyBlue,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable {
                                        passwordVisible =
                                            !passwordVisible
                                    }
                                    .padding(
                                        horizontal = 8.dp
                                    )
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SkyBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedTextColor = DarkText,
                            unfocusedTextColor = DarkText,
                            cursorColor = SkyBlue
                        )
                    )

                    // -------------------------------------------------
                    // FORGOT PASSWORD
                    // -------------------------------------------------

                    Box(
                        modifier = Modifier.fillMaxWidth()
                    ) {

                        Text(
                            text = "Forgot password?",
                            color = SkyBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .clickable {
                                    resetPassword()
                                }
                                .padding(
                                    top = 8.dp
                                )
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(22.dp)
                    )

                    // -------------------------------------------------
                    // ERROR / SUCCESS MESSAGE
                    // -------------------------------------------------

                    if (errorMessage.isNotEmpty()) {

                        Text(
                            text = errorMessage,
                            color = ErrorRed,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    bottom = 12.dp
                                )
                        )
                    }

                    if (successMessage.isNotEmpty()) {

                        Text(
                            text = successMessage,
                            color = Color(0xFF2E7D32),
                            fontSize = 11.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(
                                    bottom = 12.dp
                                )
                        )
                    }

                    // -------------------------------------------------
                    // LOGIN BUTTON
                    // -------------------------------------------------

                    Button(
                        onClick = {
                            loginOrganizer()
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SkyBlue,
                            contentColor = Color.White,
                            disabledContainerColor = SkyBlue.copy(alpha = 0.6f),
                            disabledContentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(
                            defaultElevation = 5.dp,
                            pressedElevation = 1.dp
                        )
                    ) {

                        Text(
                            text = if (isLoading) {
                                "Logging in..."
                            } else {
                                "Login"
                            },
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(25.dp)
                    )

                    // -------------------------------------------------
                    // OR
                    // -------------------------------------------------

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {

                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = BorderGrey
                        )

                        Text(
                            text = "  OR  ",
                            color = SoftText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )

                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = BorderGrey
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(23.dp)
                    )

                    // -------------------------------------------------
                    // GOOGLE LOGIN
                    // -------------------------------------------------

                    Button(
                        onClick = onGoogleLogin,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(55.dp)
                            .border(
                                width = 1.dp,
                                color = BorderGrey,
                                shape = RoundedCornerShape(14.dp)
                            ),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = DarkText
                        ),
                        elevation = ButtonDefaults.buttonElevation(
                            defaultElevation = 2.dp
                        )
                    ) {

                        Text(
                            text = "G",
                            color = SkyBlueDark,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(
                            modifier = Modifier.size(10.dp)
                        )

                        Text(
                            text = "Continue with Google",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(20.dp)
                    )

                    // -------------------------------------------------
                    // CREATE ORGANIZER ACCOUNT
                    // -------------------------------------------------

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clickable {
                                onCreateAccount()
                            },
                        contentAlignment = Alignment.Center
                    ) {

                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Text(
                                text = "New organizer?",
                                color = SoftText,
                                fontSize = 11.sp
                            )

                            Spacer(
                                modifier = Modifier.width(5.dp)
                            )

                            Text(
                                text = "Create New Organizer Account",
                                color = SkyBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}