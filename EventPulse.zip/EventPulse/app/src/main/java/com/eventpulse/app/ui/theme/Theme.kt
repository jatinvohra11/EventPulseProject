package com.eventpulse.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val EventPulseColorScheme = lightColorScheme(

    primary = EventPulseSkyBlueDark,
    onPrimary = EventPulseSurface,

    primaryContainer = EventPulseSkyBlueLight,
    onPrimaryContainer = EventPulseTextPrimary,

    secondary = EventPulseSkyBlue,
    onSecondary = EventPulseSurface,

    background = EventPulseBackground,
    onBackground = EventPulseTextPrimary,

    surface = EventPulseSurface,
    onSurface = EventPulseTextPrimary,

    surfaceVariant = EventPulseSurfaceSoft,
    onSurfaceVariant = EventPulseTextSecondary,

    outline = EventPulseBorder,

    error = EventPulseError,
    onError = EventPulseSurface
)

private val AppTypography = Typography()

@Composable
fun EventPulseTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = EventPulseColorScheme,
        typography = AppTypography,
        content = content
    )
}